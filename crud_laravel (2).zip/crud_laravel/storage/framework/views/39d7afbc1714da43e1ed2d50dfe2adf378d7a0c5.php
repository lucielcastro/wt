<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Exemplo CRUD</title>
</head>
<body>
<form action="/cadastrar-presidente" id="form" method="POST">
        <?php echo csrf_field(); ?>
            <h2>Cadastrar Presidente</h2>

            <label for="nome_candidato">Nome do Candidato:</label>
            <input type="text" name="nome_candidato" id="nome_candidato">

            <label for="nome_vice">Nome do Vice:</label>
            <input type="text" name="nome_vice" id="nome_vice">

            <label for="partido">Partido:</label>
            <input type="text" name="partido" id="partido">

            <label for="numero">Número:</label>
            <input type="text" name="numeo" id="numero">

            <input type="submit">
        </form>
</body>
</html><?php /**PATH C:\wamp64\crud_laravel\resources\views/presidente.blade.php ENDPATH**/ ?>