<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Exemplo CRUD</title>
</head>
<body>
<form action="/atualizar-candidato/<?php echo e($candidato->id); ?>" id="form" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field("PUT"); ?>
            <h2>Cadastrar Presidente</h2>

            <label for="nome_candidato">Nome do Candidato:</label>
            <input type="text" name="nome_candidato" id="nome_candidato" value="<?php echo e($candidato->nome_candidato); ?>">

            <label for="nome_vice">Nome do Vice:</label>
            <input type="text" name="nome_vice" id="nome_vice" value="<?php echo e($candidato->nome_vice); ?>">

            <label for="partido">Partido:</label>
            <input type="text" name="partido" id="partido" value="<?php echo e($candidato->partido); ?>">

            <label for="numero">Número:</label>
            <input type="text" name="numeo" id="numero" value="<?php echo e($candidato->numeo); ?>">

            <input type="submit">
        </form>
</body>
</html><?php /**PATH C:\wamp64\crud_laravel\resources\views/editar_candidato.blade.php ENDPATH**/ ?>