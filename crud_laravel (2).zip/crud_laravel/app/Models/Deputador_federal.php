<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Deputador_federal extends Model
{
    use HasFactory;
    protected $fillable = [
    'nome_candidato',
    'partido',
    'numeo',
    'estado',
];
}
