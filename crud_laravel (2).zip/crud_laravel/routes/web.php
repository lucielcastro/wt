<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;
use App\Models\Candidato;
use App\Models\presidente;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('presidente');
});
/*echo"tes";*/
Route::post('/cadastrar-presidente', function (Request $informacoes) {
    presidente::create([
        'nome_candidato' => $informacoes->nome_candidato,
        'nome_vice' => $informacoes->nome_vice,
        'partido'=>$informacoes->partido,
        'numeo'=>$informacoes->numeo,
    ]);
    echo"Candidato criado com sucesso!!";
});


Route::get('/mostrar-candidato/{id_do_candidato}', function ($id_do_candidato) {
    $candidato = presidente::findOrFail($id_do_candidato);
    echo "Nome_candidato: $candidato->nome_candidato";
    echo"<br/>";
    echo "Nome_vice: $candidato->nome_vice";
    echo"<br/>";
    echo "Partido: $candidato->partido";
    echo"<br/>";
    echo "Numero: $candidato->numeo";
});

Route::get('/editar-candidato/{id_do_candidato}', function ($id_do_candidato) {
    $candidato = presidente::findOrFail($id_do_candidato);
    return view('editar_presidente',['candidato'=>$candidato]);
});

Route::put('/atualizar-candidato/{id_do_candidato}', function (Request $informacoes, $id_do_candidato) {
    $candidato = presidente::findOrFail($id_do_candidato);
    $candidato->nome_candidato = $informacoes->nome_candidato;
    $candidato->nome_vice = $informacoes->nome_vice;
    $candidato->partido = $informacoes->partido;
    $candidato->numeo = $informacoes->numeo;
    $candidato->save();
    echo "Candidato atualizado com sucesso!";
});

Route::get('/excluir-candidato/{id_do_candidato}', function ($id_do_candidato) {
    $candidato = presidente::findOrFail($id_do_candidato);
    $candidato->delete();
    echo "Candidato excluindo com sucesso!";
});

