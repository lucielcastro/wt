<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;
use App\Models\Candidato;
use App\Models\Senador;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/*############################### SENADOR ############################# */
Route::get('/senador', function () {
   return view('senador');
});


Route::post('/cadastrar-senador', function (Request $informacoes) {
    presidente::create([
        'nome_candidato' => $informacoes->nome_candidato,
        'partido'=>$informacoes->partido,
        'numeo'=>$informacoes->numeo,
        'estado'=>$informacoes->estado,
    ]);
    echo"Candidato criado com sucesso!!";
});


Route::get('/mostrar-senador/{id_do_candidato}', function ($id_do_candidato) {
    $candidato = presidente::findOrFail($id_do_candidato);
    echo "Nome_Senador: $candidato->nome_candidato";
    echo"<br/>";
    echo "Partido: $candidato->partido";
    echo"<br/>";
    echo "Numero: $candidato->numeo";
    echo"<br/>";
    echo "Estado: $candidato->estado";
});

Route::get('/editar-senador/{id_do_candidato}', function ($id_do_candidato) {
    $candidato = presidente::findOrFail($id_do_candidato);
    return view('editar_candidato',['candidato'=>$candidato]);
});

Route::put('/atualizar-senador/{id_do_candidato}', function (Request $informacoes, $id_do_candidato) {
    $candidato = presidente::findOrFail($id_do_candidato);
    $candidato->nome_candidato = $informacoes->nome_candidato;
    $candidato->nome_vice = $informacoes->nome_vice;
    $candidato->partido = $informacoes->partido;
    $candidato->numeo = $informacoes->numeo;
    $candidato->save();
    echo "Candidato atualizado com sucesso!";
});

Route::get('/excluir-senador/{id_do_candidato}', function ($id_do_candidato) {
    $candidato = presidente::findOrFail($id_do_candidato);
    $candidato->delete();
    echo "Candidato excluindo com sucesso!";
});
